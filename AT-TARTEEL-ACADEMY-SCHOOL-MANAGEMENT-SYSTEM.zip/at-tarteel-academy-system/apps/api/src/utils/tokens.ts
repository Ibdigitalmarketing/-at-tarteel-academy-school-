import jwt from 'jsonwebtoken';
import { createHash, randomBytes } from 'node:crypto';
import { env } from '../config/env.js';
import type { Role } from '../models/User.js';

export type AccessPayload = { sub: string; role: Role; email: string };
export function signAccessToken(payload: AccessPayload) {
  return jwt.sign(payload, env.JWT_ACCESS_SECRET, { expiresIn: env.ACCESS_TOKEN_TTL as jwt.SignOptions['expiresIn'] });
}
export function createRefreshToken() { return randomBytes(48).toString('base64url'); }
export function hashToken(token: string) { return createHash('sha256').update(token).digest('hex'); }
export function verifyAccessToken(token: string) {
  return jwt.verify(token, env.JWT_ACCESS_SECRET) as AccessPayload;
}
