import { Router } from 'express';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { User, ROLES, type Role } from '../models/User.js';
import { authenticate, allowRoles } from '../middleware/auth.js';
import { writeAudit } from '../services/audit.js';

export const usersRouter = Router();
usersRouter.use(authenticate);

const createSchema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().email().max(254),
  password: z.string().min(12).max(128),
  role: z.enum(ROLES)
});

usersRouter.post('/', async (req, res, next) => {
  try {
    const input = createSchema.parse(req.body);
    const actor = req.user!;
    const permitted: Record<Role, Role[]> = {
      SUPER_ADMIN: ['SCHOOL_ADMIN'],
      SCHOOL_ADMIN: ['TEACHER','PARENT','STUDENT'],
      TEACHER: [], PARENT: [], STUDENT: []
    };
    if (!permitted[actor.role].includes(input.role)) return res.status(403).json({ error: 'Your role cannot create this account type' });
    const user = await User.create({
      name: input.name, email: input.email.toLowerCase(),
      passwordHash: await bcrypt.hash(input.password, 12),
      role: input.role, createdBy: actor.sub
    });
    await writeAudit(req, 'USER_CREATED', 'User', user.id, { createdRole: input.role });
    res.status(201).json({ user: { id: user.id, name: user.name, email: user.email, role: user.role, isActive: user.isActive } });
  } catch (e) { next(e); }
});

usersRouter.get('/', allowRoles('SUPER_ADMIN','SCHOOL_ADMIN'), async (req, res, next) => {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 20));
    const filter: Record<string, unknown> = {};
    if (req.query.role && ROLES.includes(String(req.query.role) as Role)) filter.role = req.query.role;
    if (req.query.search) filter.$or = [
      { name: { $regex: String(req.query.search), $options: 'i' } },
      { email: { $regex: String(req.query.search), $options: 'i' } }
    ];
    const [items, total] = await Promise.all([
      User.find(filter).select('name email role isActive createdAt').sort({ createdAt: -1 }).skip((page-1)*limit).limit(limit),
      User.countDocuments(filter)
    ]);
    res.json({ items, pagination: { page, limit, total, pages: Math.ceil(total/limit) } });
  } catch (e) { next(e); }
});
