import { Router } from 'express';
import mongoose from 'mongoose';
export const healthRouter = Router();
healthRouter.get('/', (_req, res) => res.json({ status: mongoose.connection.readyState === 1 ? 'ok' : 'degraded', database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected', service: 'at-tarteel-api' }));
