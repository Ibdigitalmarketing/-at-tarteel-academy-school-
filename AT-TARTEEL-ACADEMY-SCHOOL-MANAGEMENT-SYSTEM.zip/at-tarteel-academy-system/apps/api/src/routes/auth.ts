import { Router } from 'express';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { User } from '../models/User.js';
import { env } from '../config/env.js';
import { createRefreshToken, hashToken, signAccessToken } from '../utils/tokens.js';
import { authenticate } from '../middleware/auth.js';
import { writeAudit } from '../services/audit.js';

export const authRouter = Router();
const credentials = z.object({ email: z.string().email().max(254), password: z.string().min(12).max(128) });

authRouter.post('/bootstrap-super-admin', async (req, res, next) => {
  try {
    if (!env.BOOTSTRAP_SECRET || req.body?.bootstrapSecret !== env.BOOTSTRAP_SECRET)
      return res.status(403).json({ error: 'Bootstrap is disabled or secret is incorrect' });
    if (await User.exists({ role: 'SUPER_ADMIN' })) return res.status(409).json({ error: 'Super Admin already exists' });
    const body = z.object({ bootstrapSecret: z.string(), name: z.string().trim().min(2).max(120), email: z.string().email(), password: z.string().min(14).max(128) }).parse(req.body);
    const user = await User.create({ name: body.name, email: body.email.toLowerCase(), passwordHash: await bcrypt.hash(body.password, 12), role: 'SUPER_ADMIN', emailVerifiedAt: new Date() });
    return res.status(201).json({ message: 'Initial Super Admin created. Remove BOOTSTRAP_SECRET and restart the API.', user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e) { next(e); }
});

authRouter.post('/login', async (req, res, next) => {
  try {
    const body = credentials.parse(req.body);
    const user = await User.findOne({ email: body.email.toLowerCase() }).select('+passwordHash +refreshTokenHash');
    if (!user || !user.isActive || !(await bcrypt.compare(body.password, user.passwordHash)))
      return res.status(401).json({ error: 'Invalid email or password' });
    const refresh = createRefreshToken();
    user.refreshTokenHash = hashToken(refresh);
    await user.save();
    const accessToken = signAccessToken({ sub: user.id, role: user.role, email: user.email });
    await writeAudit(req, 'AUTH_LOGIN', 'User', user.id);
    res.json({ accessToken, refreshToken: refresh, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e) { next(e); }
});

authRouter.post('/refresh', async (req, res, next) => {
  try {
    const token = z.string().min(40).parse(req.body?.refreshToken);
    const user = await User.findOne({ refreshTokenHash: hashToken(token), isActive: true }).select('+refreshTokenHash');
    if (!user) return res.status(401).json({ error: 'Invalid refresh token' });
    const nextRefresh = createRefreshToken();
    user.refreshTokenHash = hashToken(nextRefresh);
    await user.save();
    const accessToken = signAccessToken({ sub: user.id, role: user.role, email: user.email });
    res.json({ accessToken, refreshToken: nextRefresh });
  } catch (e) { next(e); }
});

authRouter.post('/logout', authenticate, async (req, res, next) => {
  try {
    await User.findByIdAndUpdate(req.user!.sub, { $set: { refreshTokenHash: null } });
    await writeAudit(req, 'AUTH_LOGOUT', 'User', req.user!.sub);
    res.status(204).send();
  } catch (e) { next(e); }
});
