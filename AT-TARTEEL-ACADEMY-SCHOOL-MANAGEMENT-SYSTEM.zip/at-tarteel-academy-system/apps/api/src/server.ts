import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import swaggerUi from 'swagger-ui-express';
import { env } from './config/env.js';
import { connectDatabase } from './config/database.js';
import { authRouter } from './routes/auth.js';
import { usersRouter } from './routes/users.js';
import { healthRouter } from './routes/health.js';
import { errorHandler, notFound } from './middleware/errors.js';

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: env.CORS_ORIGIN.split(',').map(s => s.trim()), credentials: false }));
app.use(express.json({ limit: '1mb' }));
app.use(morgan(env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use('/api', rateLimit({ windowMs: 15*60*1000, limit: 300, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api/auth', rateLimit({ windowMs: 15*60*1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api/health', healthRouter);
app.use('/api/auth', authRouter);
app.use('/api/users', usersRouter);
const openapi = {
  openapi: '3.0.3', info: { title: 'AT-TARTEEL ACADEMY API', version: '0.1.0' },
  servers: [{ url: `http://localhost:${env.PORT}` }],
  paths: {
    '/api/health': { get: { summary: 'Service health' } },
    '/api/auth/login': { post: { summary: 'Sign in using email and password' } },
    '/api/auth/refresh': { post: { summary: 'Rotate refresh token' } },
    '/api/users': { get: { summary: 'List users (Super Admin / School Admin)' }, post: { summary: 'Provision role-restricted account' } }
  }
};
app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(openapi));
app.use(notFound);
app.use(errorHandler);

await connectDatabase();
app.listen(env.PORT, () => console.log(`AT-TARTEEL API listening on ${env.PORT}`));
