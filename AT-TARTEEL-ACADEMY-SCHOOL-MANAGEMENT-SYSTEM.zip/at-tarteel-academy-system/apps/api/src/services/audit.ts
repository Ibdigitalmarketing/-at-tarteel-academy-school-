import { AuditLog } from '../models/AuditLog.js';
import type { Request } from 'express';
export async function writeAudit(req: Request, action: string, targetType: string, targetId?: string, metadata: Record<string, unknown> = {}) {
  await AuditLog.create({
    actorId: req.user?.sub ?? null, action, targetType, targetId: targetId ?? null,
    ipAddress: req.ip, userAgent: req.get('user-agent') ?? null, metadata
  });
}
