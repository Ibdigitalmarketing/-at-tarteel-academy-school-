import type { Request, Response, NextFunction } from 'express';
export function notFound(_req: Request, res: Response) { res.status(404).json({ error: 'Route not found' }); }
export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  console.error(err);
  if (err && typeof err === 'object' && 'code' in err && err.code === 11000) {
    return res.status(409).json({ error: 'A record with this unique value already exists' });
  }
  return res.status(500).json({ error: 'Internal server error' });
}
