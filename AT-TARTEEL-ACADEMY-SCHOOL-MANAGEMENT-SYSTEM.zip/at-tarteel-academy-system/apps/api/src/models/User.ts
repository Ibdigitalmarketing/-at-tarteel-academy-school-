import mongoose, { Schema, type InferSchemaType } from 'mongoose';

export const ROLES = ['SUPER_ADMIN','SCHOOL_ADMIN','TEACHER','PARENT','STUDENT'] as const;
export type Role = typeof ROLES[number];

const userSchema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
  passwordHash: { type: String, required: true, select: false },
  role: { type: String, enum: ROLES, required: true, index: true },
  isActive: { type: Boolean, default: true, index: true },
  emailVerifiedAt: { type: Date, default: null },
  refreshTokenHash: { type: String, default: null, select: false },
  createdBy: { type: Schema.Types.ObjectId, ref: 'User', default: null }
}, { timestamps: true, versionKey: false });
userSchema.index({ role: 1, isActive: 1 });
export type UserDocument = InferSchemaType<typeof userSchema> & mongoose.Document;
export const User = mongoose.model('User', userSchema);
