import type { Config } from 'tailwindcss';
const config: Config = { content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'], theme: { extend: { colors: { midnight: '#101b35', royal: '#4565e8' } } }, plugins: [] };
export default config;
