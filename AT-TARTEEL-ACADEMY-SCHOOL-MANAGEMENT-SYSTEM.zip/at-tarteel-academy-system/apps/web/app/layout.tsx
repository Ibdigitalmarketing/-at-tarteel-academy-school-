import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'AT-TARTEEL ACADEMY | School Management',
  description: 'Nurturing Knowledge, Building Character, Inspiring Excellence.'
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
