import { GraduationCap, Users, BookOpen, CalendarCheck, Wallet, ClipboardList, LibraryBig, BusFront, ShieldCheck, ArrowUpRight } from 'lucide-react';

const modules = [
  {name:'Student records',desc:'Admissions, student profiles and guardians',icon:Users},
  {name:'Staff & teachers',desc:'Staff directory and role assignments',icon:GraduationCap},
  {name:'Classes & subjects',desc:'Academic structure and subject setup',icon:BookOpen},
  {name:'Attendance',desc:'Daily attendance and attendance reports',icon:CalendarCheck},
  {name:'Fees & finance',desc:'Fee schedules, invoices and payment tracking',icon:Wallet},
  {name:'Examinations',desc:'Assessments, grading and report cards',icon:ClipboardList},
  {name:'Digital library',desc:'Learning resources and library services',icon:LibraryBig},
  {name:'Transport',desc:'Routes, vehicles and transport assignments',icon:BusFront}
];

export default function Home() {
 return <main className="min-h-screen">
  <aside className="fixed inset-y-0 left-0 hidden w-64 flex-col bg-[#101b35] p-6 text-white lg:flex">
   <div className="mb-12 flex items-center gap-3"><div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-indigo-300 to-blue-600 font-black">TA</div><div><b className="text-sm tracking-widest">AT-TARTEEL</b><p className="text-xs text-slate-400">ACADEMY PORTAL</p></div></div>
   <p className="mb-3 text-[10px] font-bold tracking-[.2em] text-slate-500">WORKSPACE</p>
   <div className="space-y-2 text-sm"><div className="rounded-xl bg-white/10 px-4 py-3">▦ &nbsp; Overview</div><div className="px-4 py-3 text-slate-300">♙ &nbsp; Academics</div><div className="px-4 py-3 text-slate-300">▤ &nbsp; Administration</div><div className="px-4 py-3 text-slate-300">₦ &nbsp; Finance</div><div className="px-4 py-3 text-slate-300">⚙ &nbsp; Settings</div></div>
   <div className="mt-auto rounded-2xl border border-white/10 bg-white/5 p-4 text-xs leading-6 text-slate-300">Nurturing Knowledge,<br/>Building Character,<br/>Inspiring Excellence.</div>
  </aside>
  <section className="lg:pl-64">
   <header className="flex h-[76px] items-center justify-between border-b border-slate-200 bg-white px-5 md:px-9"><div className="text-sm text-slate-500">School Management / <b className="text-slate-900">Overview</b></div><div className="flex items-center gap-3"><span className="hidden text-right sm:block"><b className="block text-xs">Administrator preview</b><small className="text-slate-400">AT-TARTEEL ACADEMY</small></span><div className="grid h-10 w-10 place-items-center rounded-full bg-indigo-100 font-bold text-indigo-700">A</div></div></header>
   <div className="mx-auto max-w-7xl p-5 md:p-9">
    <div className="mb-7 flex flex-wrap items-end justify-between gap-4"><div><p className="mb-2 text-xs font-bold uppercase tracking-[.22em] text-indigo-600">School administration</p><h1 className="text-2xl font-bold tracking-tight md:text-3xl">Welcome to AT-TARTEEL ACADEMY</h1><p className="mt-2 text-sm text-slate-500">A unified workspace for managing school operations.</p></div><span className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-xs text-slate-500">System foundation · Phase 1</span></div>
    <div className="mb-7 rounded-2xl border border-indigo-100 bg-indigo-50 p-4 text-sm leading-6 text-indigo-950"><b>Deployment note:</b> This is the frontend dashboard foundation. Connect the API and configure secure administrator access before entering any real school records.</div>
    <div className="mb-7 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
     {[['Students','—','Records populate after admissions module is enabled',Users],['Teachers','—','Staff accounts populate from the API',GraduationCap],['Attendance','—','Daily attendance reporting',CalendarCheck],['Fee revenue','—','Financial data is not connected yet',Wallet]].map(([title,value,note,Icon]:any)=><div key={title} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="flex items-center justify-between text-sm text-slate-500"><span>{title}</span><span className="rounded-xl bg-indigo-50 p-2 text-indigo-600"><Icon size={18}/></span></div><div className="mt-4 text-3xl font-bold">{value}</div><p className="mt-1 text-xs text-slate-400">{note}</p></div>)}
    </div>
    <div className="mb-4 flex items-center justify-between"><h2 className="font-bold">School modules</h2><span className="text-xs text-slate-400">Module rollout plan</span></div>
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{modules.map(({name,desc,icon:Icon})=><article key={name} className="group rounded-2xl border border-slate-200 bg-white p-5 transition hover:-translate-y-1 hover:shadow-lg"><div className="mb-5 flex items-center justify-between"><span className="rounded-xl bg-slate-100 p-3 text-indigo-700"><Icon size={20}/></span><ArrowUpRight size={17} className="text-slate-300 transition group-hover:text-indigo-600"/></div><h3 className="font-semibold">{name}</h3><p className="mt-2 text-xs leading-5 text-slate-500">{desc}</p></article>)}</div>
    <div className="mt-7 rounded-2xl bg-[#101b35] p-6 text-white"><div className="flex items-start gap-4"><ShieldCheck className="mt-1 text-emerald-300" size={24}/><div><h2 className="font-semibold">Security-first account policy</h2><p className="mt-2 max-w-3xl text-sm leading-6 text-slate-300">There is no public student, parent, or teacher sign-up. The API enforces account provisioning rules: only the Super Admin can create School Admin accounts; School Admins can create Teacher, Parent, and Student accounts.</p></div></div></div>
    <footer className="py-9 text-center text-xs text-slate-400">© {new Date().getFullYear()} AT-TARTEEL ACADEMY · School Management System</footer>
   </div>
  </section>
 </main>;
}
